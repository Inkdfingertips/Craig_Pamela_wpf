//Pamela Craig WPF 
//WDD144-O sec 01 
//Wacky Expression//
var coffeeCup = 3
//var coffe cup the the number of coffee cups you drink in a day
var ouncesOfCoffee = 28
//var ounces of coffee you have drank in a day
var days = 6
// var how many days you have exisited on coffee
var total = (coffeeCup * ouncesOfCoffee * days);
//var total mutilpes the cups of coffee, ounces of coffee, and days together
console.log ("The total number of ounces of cup you've drank is " + total);
//check this online through the console
