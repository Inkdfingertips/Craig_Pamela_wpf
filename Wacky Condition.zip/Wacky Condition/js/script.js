//Pamela Craig
//7/24/14
//Wacky Conditional 
alert("Let's play complete the lyrics!");
//Alert box wanting to play a game with you. Do it.
fallOutBoy = prompt ("My songs know what you did in the---");
//First question
panicAtTheDisco = prompt("Miss Jackson, are you---")
//second question
if (fallOutBoy == "dark")
	{console.log("You know the lyrics to Fall Out Boy's latest single!")
}
if (panicAtTheDisco == "nasty")
	{console.log("You know Panic at the Disco's latest single!");
} //answers are above
else {console.log ("Seriously? Neither one? Dang.");
} //You didn't know them did you?