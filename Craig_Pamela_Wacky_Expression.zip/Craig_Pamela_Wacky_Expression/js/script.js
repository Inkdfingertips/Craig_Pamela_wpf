//Pamela Craig WPF 
//WDD144-O sec 01 
//Wacky Expression//
var age = 27;
//enter your age on your planet//
var height = 6.0;
//How far do you strech from the ground//
var weight = 205;
//keeping your gravity in mind, how much do you weigh//
var birthLocation = "Chicago";
//Where on your home palnet were you born//
var towelCount = 9;
//How many towels do you have in your possession//
var guideToGalaxy = [age, height, weight, birthLocation, towelCount];
//This is a list of the above placed into an easy list//
console.log ("The array of information is " + guideToGalaxy)
//This is where you check the work online. The array of information plus guideToGalaxy//
console.log ("The answer is always 42")
//No matter what you've entered the anser to life is always 42//